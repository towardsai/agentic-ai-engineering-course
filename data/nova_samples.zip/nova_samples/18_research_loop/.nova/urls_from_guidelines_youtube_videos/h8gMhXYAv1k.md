# Tool Calling: Traditional vs. Embedded Explained

[00:00]  
**Roy Derks**: So, what is tool calling? Tool calling is a powerful technique where you make the LLM context-aware of real-time data, such as databases or APIs. Typically, you use tool calling via a chat interface.  

*(Roy writes "chat" at the top of the board, followed by "APP" on the left side and "LLM" on the right side to establish the two main components.)*  

[00:30]  
**Roy Derks**: So, you would have your client application on one hand, and the LLM on the other side. From your client application, you would send a set of messages, together with a tool definition, to the LLM.  

*(He draws a green arrow pointing from "APP" to "LLM" and writes "messages + tools" over it.)*  

**Roy Derks**: So, you would have your messages here, together with your list of tools. The LLM will look at both your message and the list of tools, and it's going to recommend a tool you should call.  

*(He draws a return arrow from "LLM" to "APP" and writes "tool to call".)*  

[01:00]  
**Roy Derks**: From your client application, you should call this tool, and then supply the answer back to the LLM.  

*(He draws another green arrow from "APP" to "LLM", writing "tool response".)*  

**Roy Derks**: So, this tool response will be interpreted by the LLM, and this will either tell you the next tool to call, or it will give you the final answer.  

*(He draws a final return arrow to the APP representing the final output.)*  

**Roy Derks**: In your application, you're responsible for creating the tool definition.  

*(Under the APP column, he writes "tool definition" in green with bullet points for "name", "description", and "input".)*  

[01:30]  
**Roy Derks**: So, this tool definition includes a couple of things, such as the name of your tool. It also includes a description for the tool, so this is where you can give additional information about how to use the tool or when to use it, and it also includes the input parameters needed to make a tool call. And the tool can be anything, so the tools could be APIs or databases...  

*(He draws a box labeled "tools" with branching circles for "API", "DB", and "Code".)*  

[02:00]  
**Roy Derks**: ...but it could also be code that you interpret via a code interpreter. So, let's look at an example. Assume you want to find the weather in Miami. You might ask the LLM about the temperature in Miami.  

*(He writes "temp in Miami" over the initial message arrow and "weather" next to the tools list.)*  

**Roy Derks**: You also provide a list of tools, and one of these tools is the weather API. The LLM will look at both your question, which is "what is the temperature in Miami", and will also look at the weather API. And then, based on the tool definition for the weather API, it's going to tell you how to call the weather tool.  

[02:30]  
**Roy Derks**: So, in here, it's going to create a tool that you can use right here on this side, where you call the API to collect the weather information. You would then supply the weather information back to the LLM. So, let's say it would be 71 degrees.  

*(He writes "71°" in pink next to the "tool response" arrow.)*  

**Roy Derks**: The LLM will look at the tool response, and then give the final answer, which might be something in the trend of "the weather in Miami is pretty nice, it's 71 degrees." This has some downsides. So, when you do traditional tool calling, where you have an LLM and a client application, you could see the LLM hallucinate.  

*(Under the LLM column, he writes "- hallucinate" and "- incorrect" in pink.)*  

[02:52]  
**Roy Derks**: Sometimes, the LLM can also make up incorrect tool calls. That's why I also want to look at embedded tool calling.  

*Traditional tool calling involves the client application directly sending messages and tool definitions to the LLM, which recommends a tool that the client must then execute and return the results for, potentially leading to hallucinations or incorrect tool calls.*  

---

[03:00]  
**Roy Derks**: We just looked at traditional tool calling, but traditional tool calling has its flaws. As I mentioned, the LLM could hallucinate or create incorrect tool calls. That's why you also want to take embedded tool calling into account. With embedded tool calling, you use a library or framework to interact with the LLM and your tool definitions. The library would be somewhere between your application and the large language model.  

*(He writes "embedded" at the top in gold and draws a large rectangle representing the "library" positioned between the "APP" and "LLM" sections.)*  

[03:30]  
**Roy Derks**: In the library, you would do the tool definition, but you would also execute the tool calls. So, let's draw a line between these sections here.  

*(He draws a line linking the APP's "tools" container directly to the library, and writes "tool def" and "tool exec" inside the library frame.)*  

**Roy Derks**: So, the library will contain your tool definition, it will also contain the tool execution. So, when you send a message from your application to the large language model, it will go through the library. So, your message could still be "what is the temperature in Miami?"  

*(He draws a green arrow from APP into the library labeled "temp in Miami?".)*  

[04:00]  
**Roy Derks**: The library will then append the tool definition and send your message together with the tools to the LLM. So, this will be your message plus your list of tools.  

*(He draws a green arrow from the library to the LLM labeled "message + tool".)*  

**Roy Derks**: Instead of sending the tool to call to the application or the user, it will be sent to the library, which will then do the tool execution. And this way, the library will provide you with the final answer...  

*(He shows the loop where the LLM responds to the library, the library executes the tool, and then returns the final output back to the APP.)*  

[04:30]  
**Roy Derks**: ...which could be "it's 71 degrees in Miami." When you use embedded tool calling, the LLM will no longer hallucinate, as the library to help you with the tool calling, or the embedded tool calling, is going to take care of the tool execution and will retry the tool calls in case it's needed.  

**Roy Derks**: So, in this video, we looked at both traditional tool calling and also embedded tool calling, where especially embedded tool calling will help you to prevent hallucination or help you with the execution of tools, which could be APIs, databases, or code.  

*(The video fades into an IBM logo outro.)*  

*Embedded tool calling introduces an intermediary library or framework between the application and the LLM to handle both tool definitions and executions, reducing hallucinations and managing retries automatically.*