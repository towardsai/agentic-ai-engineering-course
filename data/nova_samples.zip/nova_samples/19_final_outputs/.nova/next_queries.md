### Candidate Web-Search Queries

1. What are the fundamental limitations of large language models that tool use and function calling are designed to overcome?
Reason: This query targets the core 'why' for the article's section on 'Understanding why agents need tools'. The existing sources are strong on the 'how' but lack depth on the conceptual necessity. This will find sources explaining issues like knowledge cutoffs, lack of real-time data, and the inability to perform external actions, providing a solid foundation for the entire article.

2. What are the architectural patterns and best practices for designing robust LLM agents with a large number of tools?
Reason: This query moves beyond the basic API documentation to address a key engineering challenge. It will uncover expert-level content on topics like tool retrieval, dynamic tool loading (like OpenAI's 'tool search'), and agentic frameworks, providing a comparative and practical perspective that bridges the gap between simple API calls and complex, real-world applications.

3. What are the key differences and trade-offs between JSON schema-based function calling and custom grammars (like CFGs) for LLM tool use?
Reason: This query focuses on a specific, advanced comparison between two distinct methods of tool definition mentioned in the provided context (JSON schema vs. Lark/Regex grammars). It will yield sources that analyze the pros and cons of structured vs. flexible tool inputs, helping to write a nuanced section on advanced tool design and its implications for agent reliability and capability.

